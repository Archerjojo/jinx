console.log("Application.js loaded");

// 定义背景音乐的全局变量
var backgroundMusic = new Audio('music/五音Jw+-+天涯共此时.mp3'); // 设置为相对路径
backgroundMusic.loop = true; // 使音乐循环播放
backgroundMusic.volume = 1.0; // 将音量设置为最大值

backgroundMusic.addEventListener('canplaythrough', function() {
  console.log("Background music can play through.");
}, false);

backgroundMusic.addEventListener('error', function(e) {
  console.error("Error loading background music: ", e);
}, false);

// 切换音乐播放和暂停的函数
function toggleMusic() {
  console.log("Toggle Music clicked");
  if (backgroundMusic.paused) {
    backgroundMusic.play().then(() => {
      console.log("Music playing");
    }).catch(error => {
      console.error("Error playing music: ", error);
    });
  } else {
    backgroundMusic.pause();
    console.log("Music paused");
  }
}

// 在游戏初始化时绑定音乐切换事件
window.requestAnimationFrame(function () {
  console.log("RequestAnimationFrame called");
  var gameManager = new GameManager(4, KeyboardInputManager, HTMLActuator, LocalStorageManager);

  // 监听背景音乐切换事件
  gameManager.inputManager.on("toggleMusic", toggleMusic);
});



