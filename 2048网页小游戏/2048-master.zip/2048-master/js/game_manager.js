// GameManager类的构造函数，初始化游戏的大小、输入管理器、渲染器和存储管理器
function GameManager(size, InputManager, Actuator, StorageManager) {
  this.size = size; // 网格的大小（例如4x4的网格）
  this.inputManager = new InputManager(); // 输入管理器实例
  this.storageManager = new StorageManager(); // 存储管理器实例
  this.actuator = new Actuator(); // 渲染器实例

  this.startTiles = 2; // 游戏开始时的初始方块数

  // 绑定事件处理函数到相应的事件
  this.inputManager.on("move", this.move.bind(this)); // 用户移动时触发
  this.inputManager.on("restart", this.restart.bind(this)); // 用户点击重启时触发
  this.inputManager.on("keepPlaying", this.keepPlaying.bind(this)); // 用户点击继续游戏时触发

  this.setup(); // 初始化游戏状态
}

// 重启游戏
GameManager.prototype.restart = function () {
  this.storageManager.clearGameState(); // 清除存储的游戏状态
  this.actuator.continueGame(); // 清除游戏胜利或失败的信息
  this.setup(); // 重新设置游戏
};

// 继续游戏（在达到2048后）
GameManager.prototype.keepPlaying = function () {
  this.keepPlaying = true; // 设置继续游戏标志
  this.actuator.continueGame(); // 清除游戏胜利或失败的信息
};

// 判断游戏是否结束（失败或者胜利后未继续）
GameManager.prototype.isGameTerminated = function () {
  return this.over || (this.won && !this.keepPlaying); // 游戏结束或者胜利但未选择继续游戏
};

// 设置游戏
GameManager.prototype.setup = function () {
  var previousState = this.storageManager.getGameState(); // 获取之前的游戏状态

  if (previousState) {
    // 如果存在之前的游戏状态，则加载它
    this.grid = new Grid(previousState.grid.size, previousState.grid.cells); // 重新加载网格
    this.score = previousState.score; // 恢复分数
    this.over = previousState.over; // 恢复游戏结束状态
    this.won = previousState.won; // 恢复胜利状态
    this.keepPlaying = previousState.keepPlaying; // 恢复继续游戏状态
  } else {
    // 否则初始化新的游戏状态
    this.grid = new Grid(this.size); // 创建新的网格
    this.score = 0; // 初始化分数
    this.over = false; // 游戏未结束
    this.won = false; // 游戏未胜利
    this.keepPlaying = false; // 未选择继续游戏

    this.addStartTiles(); // 添加初始方块
  }

  this.actuate(); // 更新视图
};

// 添加初始方块
GameManager.prototype.addStartTiles = function () {
  for (var i = 0; i < this.startTiles; i++) {
    this.addRandomTile(); // 在随机位置添加方块
  }
};

// 在随机位置添加一个方块
GameManager.prototype.addRandomTile = function () {
  if (this.grid.cellsAvailable()) {
    var value = Math.random() < 0.9 ? 2 : 4; // 90%的概率生成值为2的方块，10%的概率生成值为4的方块
    var tile = new Tile(this.grid.randomAvailableCell(), value); // 创建新的方块

    this.grid.insertTile(tile); // 将方块插入网格
  }
};

// 更新视图
GameManager.prototype.actuate = function () {
  if (this.storageManager.getBestScore() < this.score) {
    this.storageManager.setBestScore(this.score); // 如果当前分数高于最高分，则更新最高分
  }

  if (this.over) {
    this.storageManager.clearGameState(); // 如果游戏结束，则清除存储的游戏状态
  } else {
    this.storageManager.setGameState(this.serialize()); // 否则保存当前游戏状态
  }

  this.actuator.actuate(this.grid, {
    score: this.score, // 当前分数
    over: this.over, // 游戏结束状态
    won: this.won, // 游戏胜利状态
    bestScore: this.storageManager.getBestScore(), // 最高分
    terminated: this.isGameTerminated() // 游戏是否结束
  });
};

// 序列化当前游戏状态
GameManager.prototype.serialize = function () {
  return {
    grid: this.grid.serialize(), // 序列化网格
    score: this.score, // 当前分数
    over: this.over, // 游戏结束状态
    won: this.won, // 游戏胜利状态
    keepPlaying: this.keepPlaying // 继续游戏状态
  };
};

// 为下一次移动准备瓦片
GameManager.prototype.prepareTiles = function () {
  // 遍历网格中的每个单元格
  this.grid.eachCell(function (x, y, tile) {
    if (tile) {
      tile.mergedFrom = null; // 清除瓦片的合并信息，表示该瓦片没有被合并
      tile.savePosition(); // 保存瓦片的当前位置，以便在下一次移动时比较
    }
  });
};

// 移动方块
GameManager.prototype.moveTile = function (tile, cell) {
  this.grid.cells[tile.x][tile.y] = null; // 将当前方块位置设为空
  this.grid.cells[cell.x][cell.y] = tile; // 将方块移动到新的位置
  tile.updatePosition(cell); // 更新方块位置
};

// 根据指定方向移动方块
GameManager.prototype.move = function (direction) {
  var self = this;

  if (this.isGameTerminated()) return; // 如果游戏结束则不执行任何操作

  var cell, tile;

  var vector = this.getVector(direction); // 获取移动方向的向量
  var traversals = this.buildTraversals(vector); // 构建遍历顺序
  var moved = false;

  this.prepareTiles(); // 准备方块，移除合并信息

  traversals.x.forEach(function (x) {
    traversals.y.forEach(function (y) {
      cell = { x: x, y: y };
      tile = self.grid.cellContent(cell);

      if (tile) {//能和并就合并，不能就移到最远处
        var positions = self.findFarthestPosition(cell, vector); // 找到最远的位置
        var next = self.grid.cellContent(positions.next);

        if (next && next.value === tile.value && !next.mergedFrom) {
          var merged = new Tile(positions.next, tile.value * 2); // 合并方块
          merged.mergedFrom = [tile, next];

          self.grid.insertTile(merged); // 插入合并后的方块
          self.grid.removeTile(tile); // 移除原方块

          tile.updatePosition(positions.next); // 更新位置

          self.score += merged.value; // 更新分数

          if (merged.value === 2048) self.won = true; // 达到2048则胜利
        } else {
          self.moveTile(tile, positions.farthest); // 移动方块到最远位置
        }

        if (!self.positionsEqual(cell, tile)) {//记录方块是否移动，比较两个位置是否相同
          moved = true; 
        }
      }
    });
  });

  if (moved) {
    this.addRandomTile(); // 移动成功则添加一个新方块

    if (!this.movesAvailable()) {
      this.over = true; // 没有可移动的则游戏结束
    }

    this.actuate(); // 更新视图
  }
};

// 获取移动方向的向量
GameManager.prototype.getVector = function (direction) {
  var map = {
    0: { x: 0, y: -1 }, // 上
    1: { x: 1, y: 0 }, // 右
    2: { x: 0, y: 1 }, // 下
    3: { x: -1, y: 0 } // 左
  };

  return map[direction];
};

// 构建遍历顺序
GameManager.prototype.buildTraversals = function (vector) {
  var traversals = { x: [], y: [] }; // 初始化遍历顺序对象，包含 x 和 y 两个数组

  // 填充遍历顺序数组
  for (var pos = 0; pos < this.size; pos++) {
    traversals.x.push(pos); // 将 0 到 this.size-1 的索引添加到 x 数组中
    traversals.y.push(pos); // 将 0 到 this.size-1 的索引添加到 y 数组中
  }

  // 根据移动方向调整遍历顺序
  if (vector.x === 1) traversals.x = traversals.x.reverse(); // 如果向右移动，则反转 x 数组的顺序
  if (vector.y === 1) traversals.y = traversals.y.reverse(); // 如果向下移动，则反转 y 数组的顺序

  return traversals; // 返回构建好的遍历顺序对象
};


// 找到最远的位置
GameManager.prototype.findFarthestPosition = function (cell, vector) {
  var previous;

  do {
    previous = cell;
    cell = { x: previous.x + vector.x, y: previous.y + vector.y };
  } while (this.grid.withinBounds(cell) && this.grid.cellAvailable(cell));

  return {
    farthest: previous, // 最远可达位置
    next: cell // 用于检查是否需要合并
  };
};

// 检查是否有可移动的方块
GameManager.prototype.movesAvailable = function () {
  return this.grid.cellsAvailable() || this.tileMatchesAvailable();
};

// 检查是否有可合并的方块
GameManager.prototype.tileMatchesAvailable = function () {
  var self = this;

  var tile;

  for (var x = 0; x < this.size; x++) {
    for (var y = 0; y < this.size; y++) {
      tile = this.grid.cellContent({ x: x, y: y });

      if (tile) {
        for (var direction = 0; direction < 4; direction++) {
          var vector = self.getVector(direction);
          var cell = { x: x + vector.x, y: y + vector.y };

          var other = self.grid.cellContent(cell);

          if (other && other.value === tile.value) {
            return true; // 这两个方块可以合并
          }
        }
      }
    }
  }

  return false;
};

// 比较两个位置是否相同
GameManager.prototype.positionsEqual = function (first, second) {
  return first.x === second.x && first.y === second.y;
};
